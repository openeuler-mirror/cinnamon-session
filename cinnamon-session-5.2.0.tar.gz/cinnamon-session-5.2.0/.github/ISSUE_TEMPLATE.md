
```
 * cinnamon-session version (cinnamon-session --version)
 * Distribution - (Mint 17.2, Arch, Fedora 25, etc...)
 * Graphics hardware *and* driver used
 * 32 or 64 bit
 ```

**Issue**



**Steps to reproduce**



**Expected behaviour**



**Other information**
